For creating AWS lambda function using terraform, the zip has to be uploaded, so this zip and file are for `terraform apply`.
